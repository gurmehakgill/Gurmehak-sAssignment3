export class Pet {
    public id!: number;
    public name!: string ;
    public petKind!: string ;
    public age!: number;
    public image!: string ;
    public description!: string ;
    public breed!: string ;
  }
  