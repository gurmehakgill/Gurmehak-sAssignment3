import { DataJson } from "./catalog-json";

export const data: DataJson =
{
    "pets": [
      {
        "id": 1,
        "name": "Fluffy",
        "petKind": "Cat",
        "age": 4,
        "image": 'fluffy_cat.jpg',
        "description": "Fluffy is an affectionate Persian cat with a penchant for napping in sunlit spots and showering its human companions with love and purrs.",
        "breed": "Persian Cat"
      },
      {
        "id": 2,
        "name": "Oscar",
        "petKind": "Cat",
        "age": 1,
        "image": 'oscar_cat.jpg',
        "description": "Oscar is a dignified Siamese cat with an air of sophistication and a penchant for lounging in regal splendor, captivating all who behold his majestic presence.",
        "breed": "Siamese Cat"
      },
      {
        "id": 3,
        "name": "Sam",
        "petKind": "Rabbit",
        "age": 3,
        "image": 'sam_rabbit.jpg',
        "description": "Sam is a mischievous yet endearing Holland Lop rabbit who delights in exploring its surroundings, munching on crunchy veggies, and bestowing affectionate nose bonks upon its favorite humans.",
        "breed": "Holland Lop Rabbit"
      },
      {
        "id": 4,
        "name": "Riley",
        "petKind": "Dog",
        "age": 3,
        "image": 'riley_dog.jpg',
        "description": "Riley is an energetic and intelligent Border Collie who thrives on mental stimulation and enjoys partaking in outdoor activities with its devoted human companion.",
        "breed": "Border Collie"
      },
      {
        "id": 5,
        "name": "Charlie",
        "petKind": "Dog",
        "age": 4,
        "image": 'charlie_dog.jpg',
        "description": "Charlie is a loyal and adventurous German Shepherd who loves embarking on outdoor escapades and cuddling up with its family at the end of the day.",
        "breed": "German Shepherd"
      },
      {
        "id": 6,
        "name": "Marx",
        "petKind": "Hamster",
        "age": 2,
        "image": 'marx_hamster.jpg',
        "description": "Marx is a curious and playful hamster who enjoys exploring every nook and cranny of its habitat, spreading cheer wherever it goes.",
        "breed": "Roborovski Hamster"
      },
      {
        "id": 7,
        "name": "Tweety",
        "petKind": "Canary",
        "age": 2,
        "image": 'tweety_canary.jpg',
        "description": "Tweety is a charming canary with a penchant for serenading the sunrise and spreading joy with its delightful chirps.",
        "breed": "Fife Fancy Canary"
      }
    ]
}