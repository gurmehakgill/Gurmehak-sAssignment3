import { Component } from '@angular/core';
import { PetDataService } from '../pet-data.service';
import { Pet } from '../pet';

@Component({
  selector: 'app-pet-image',
  templateUrl: './pet-image.component.html',
  styleUrl: './pet-image.component.css'
})
export class PetImageComponent {
  pets: Pet[];

  constructor(petDataService: PetDataService) 
  {
    this.pets = petDataService.getPetList();
  }
}
